# Project :- Ecommerce Sales


```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import warnings
warnings.filterwarnings("ignore")
```


```python
import mysql.connector as msc
```


```python
csv_files = [
    ('customers.csv','customers'),
    ('geolocation.csv','geolocation'),
    ('order_items.csv','orders_items'),
    ('orders.csv','orders'),
    ('payments.csv','payments'),
    ('products.csv','products'),
    ('sellers.csv', 'sellers')
]
```


```python
from sqlalchemy import create_engine
```


```python
# Connect to the mysql database

conn = msc.connect(host = '127.0.0.1',
                   username = 'root',
                   password =  'Vinay@2002',
                  database = 'Ecommerce')


cur = conn.cursor()
                

```


```python

# Folder containing the CSV files
folder_path = "C:/Users/Vinay Raykar/OneDrive/Documents/My Courses/Youtube Projects/Project 3-  E-Commerce Sales/Ecommerce Dataset"

def get_sql_type(dtype):
    if pd.api.types.is_integer_dtype(dtype):
        return 'INT'
    elif pd.api.types.is_float_dtype(dtype):
        return 'FLOAT'
    elif pd.api.types.is_bool_dtype(dtype):
        return 'BOOLEAN'
    elif pd.api.types.is_datetime64_any_dtype(dtype):
        return 'DATETIME'
    else:
        return 'TEXT'

for csv_file, table_name in csv_files:
    file_path = os.path.join(folder_path, csv_file)
    
    # Read the CSV file into a pandas DataFrame
    df = pd.read_csv(file_path)
    
    # Replace NaN with None to handle SQL NULL
    df = df.where(pd.notnull(df), None)
    
    # Debugging: Check for NaN values
    print(f"Processing {csv_file}")
    print(f"NaN values before replacement:\n{df.isnull().sum()}\n")

    # Clean column names
    df.columns = [col.replace(' ', '_').replace('-', '_').replace('.', '_') for col in df.columns]

    # Generate the CREATE TABLE statement with appropriate data types
    columns = ', '.join([f'`{col}` {get_sql_type(df[col].dtype)}' for col in df.columns])
    create_table_query = f'CREATE TABLE IF NOT EXISTS `{table_name}` ({columns})'
    cur.execute(create_table_query)

    # Insert DataFrame data into the MySQL table
    for _, row in df.iterrows():
        # Convert row to tuple and handle NaN/None explicitly
        values = tuple(None if pd.isna(x) else x for x in row)
        sql = f"INSERT INTO `{table_name}` ({', '.join(['`' + col + '`' for col in df.columns])}) VALUES ({', '.join(['%s'] * len(row))})"
        cur.execute(sql, values)

    # Commit the transaction for the current CSV file
    conn.commit()

# Close the connection
conn.close()

```


```python
## Creation of database
# query = 'CREATE DATABASE Ecommerce'

# cur.execute(query)

# conn.commit()
# conn.close()
```


```python
import matplotlib.pyplot as plt
import seaborn as sns
```


# Basic Queries

**List all unique cities where customers are located.**


```python
conn = msc.connect(host = '127.0.0.1',
                   username = 'root',
                   password =  'Vinay@2002',
                  database = 'Ecommerce')


cur = conn.cursor()

query = "Select DISTINCT customer_city from customers"
cur.execute(query)

data = cur.fetchall()

unique_city = pd.DataFrame(data, columns = ["Customer's City"])

```


```python
print(f"There are {unique_city.value_counts().sum()} unique customer's cities")
unique_city
```

    There are 4119 unique customer's cities
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer's City</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>franca</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sao bernardo do campo</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sao paulo</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mogi das cruzes</td>
    </tr>
    <tr>
      <th>4</th>
      <td>campinas</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>4114</th>
      <td>siriji</td>
    </tr>
    <tr>
      <th>4115</th>
      <td>natividade da serra</td>
    </tr>
    <tr>
      <th>4116</th>
      <td>monte bonito</td>
    </tr>
    <tr>
      <th>4117</th>
      <td>sao rafael</td>
    </tr>
    <tr>
      <th>4118</th>
      <td>eugenio de castro</td>
    </tr>
  </tbody>
</table>
<p>4119 rows × 1 columns</p>
</div>




```python

```


```python

```

**2. Count the number of orders placed in 2017.**


```python
query = """Select count(order_id) from orders WHERE year(order_approved_at) = 2017"""
cur.execute(query)

data = cur.fetchall()
print("Total order were placed in 2017:-", data[0][0], "Units")
```

    Total order were placed in 2017:- 89946 Units
    


```python

```

**3. Find the total sales per category.**


```python
query = """SELECT CONCAT(UPPER(LEFT(products.product_category,1)), LOWER(SUBSTRING(products.product_category,2))) as category, 
round(sum(payments.payment_value),2) as price
FROM products JOIN orders_items
ON products.product_id = orders_items.product_id
JOIN payments
ON payments.order_id = orders_items.order_id
GROUP BY category
ORDER BY price DESC
"""
cur.execute(query)

data = cur.fetchall()
sale_category = pd.DataFrame(data, columns = ["Category", "Sales"])
sale_category

#Drop null values from column category
clean_df = sale_category.dropna(subset = ['Category'])
print(clean_df.isnull().sum())

# Top 10 Category
clean_df = clean_df.head(10)

# Visualization
fig = plt.figure(figsize = (14,10))

plt.style.use('bmh')
# fig.patch.set_facecolor('white')

plt.barh(y = clean_df["Category"], width = clean_df["Sales"], edgecolor= 'black' , linewidth = 2, color = 'goldenrod' , hatch = '\\')

# converts into full number
plt.gca().xaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))

plt.gca().invert_yaxis()

plt.title("The total sales per category.", fontweight = 'bold', fontsize = 15)
plt.xticks(rotation =30)
plt.xlabel("Sales", fontweight = 'bold', fontsize = 11 )
plt.ylabel("Categories", fontweight = 'bold', fontsize = 11)


plt.tight_layout()
plt.show()
```

    Category    0
    Sales       0
    dtype: int64
    


    
![png](output_19_1.png)
    



```python

```


```python
print("The total sales per category.:\n")
clean_df
```

    The total sales per category.:
    
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bed table bath</td>
      <td>13700429.37</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Health beauty</td>
      <td>13258984.96</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Computer accessories</td>
      <td>12682643.57</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Furniture decoration</td>
      <td>11441411.13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Watches present</td>
      <td>11433733.43</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Sport leisure</td>
      <td>11137020.47</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Housewares</td>
      <td>8758065.04</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Automotive</td>
      <td>6818354.65</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Garden tools</td>
      <td>6706246.01</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Cool stuff</td>
      <td>6237584.00</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

**4. Calculate the percentage of orders that were paid in installments.**


```python
query1 = """SELECT (sum(CASE WHEN payment_installments >= 1 THEN 1
ELSE 0 END))/count(*)*100 FROM payments"""

cur.execute(query1)

data = cur.fetchall()

print(f'{data[0][0]} % of orders that were paid by in installments.')
```

    99.9981 % of orders that were paid by in installments.
    

**5. Count the number of customers from each state.**


```python
query = """SELECT customer_state, count(customer_unique_id) FROM customers
GROUP BY customer_state
"""

cur.execute(query)

data = cur.fetchall()

customer_count = pd.DataFrame(data, columns = ["State", "Count of customers"])

#Plot the bar graph

plt.figure(figsize = (15,8))
plt.style.use('ggplot')

customer_count = customer_count.sort_values(by ='Count of customers', ascending = False).head(15)

#color indicator
colors = ['firebrick'] + ['c'] * 15

count = plt.bar(customer_count['State'], customer_count['Count of customers'], edgecolor = 'black', color = colors)
plt.title("Count the number of customers from each state.", fontweight = 'bold' , fontsize = 16)
plt.xlabel("State", fontweight = 'bold' , fontsize = 12)
plt.ylabel('Count of customers', fontweight = 'bold' , fontsize = 12)
plt.xticks(rotation = 0)



plt.tight_layout()
plt.show()

print('The state SP has 80k+ count of the customers number.')
```


    
![png](output_26_0.png)
    


    The state SP has 80k+ count of the customers number.
    


```python
customer_count
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>State</th>
      <th>Count of customers</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>SP</td>
      <td>125238</td>
    </tr>
    <tr>
      <th>4</th>
      <td>RJ</td>
      <td>38556</td>
    </tr>
    <tr>
      <th>2</th>
      <td>MG</td>
      <td>34905</td>
    </tr>
    <tr>
      <th>5</th>
      <td>RS</td>
      <td>16398</td>
    </tr>
    <tr>
      <th>3</th>
      <td>PR</td>
      <td>15135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SC</td>
      <td>10911</td>
    </tr>
    <tr>
      <th>9</th>
      <td>BA</td>
      <td>10140</td>
    </tr>
    <tr>
      <th>13</th>
      <td>DF</td>
      <td>6420</td>
    </tr>
    <tr>
      <th>8</th>
      <td>ES</td>
      <td>6099</td>
    </tr>
    <tr>
      <th>7</th>
      <td>GO</td>
      <td>6060</td>
    </tr>
    <tr>
      <th>15</th>
      <td>PE</td>
      <td>4956</td>
    </tr>
    <tr>
      <th>12</th>
      <td>CE</td>
      <td>4008</td>
    </tr>
    <tr>
      <th>6</th>
      <td>PA</td>
      <td>2925</td>
    </tr>
    <tr>
      <th>16</th>
      <td>MT</td>
      <td>2721</td>
    </tr>
    <tr>
      <th>10</th>
      <td>MA</td>
      <td>2241</td>
    </tr>
  </tbody>
</table>
</div>



**6. Top Customers by Revenue**


```python
query = """Select customer_unique_id as Customers,
ROUND(SUM(payments.payment_value),2) as Revenue

FROM payments 
JOIN orders
ON payments.order_id = orders.order_id
JOIN customers
ON customers.customer_id = orders.customer_id

GROUP BY Customers
ORDER BY Revenue DESc;"""


cur.execute(query)

data = cur.fetchall()
cust_reve= pd.DataFrame(data, columns = ["Customer", "Revenue"])
cust_reve = cust_reve.head(10)

```


```python
#Visualize
plt.figure(figsize = (12,9))

plt.style.use('bmh')
count = sns.barplot(data = cust_reve, x = cust_reve["Customer"], y = cust_reve["Revenue"], edgecolor= 'black' , linewidth = 2, color = 'darkcyan')

# View the values of y-axis
plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))

plt.title("Top Customers by Revenue", fontweight = 'bold', fontsize = 15, color = 'k')
plt.xticks(rotation = 90)
plt.xlabel("Customer ID", fontweight = 'bold', fontsize = 11 )
plt.ylabel("Revenue", fontweight = 'bold', fontsize = 11)


#Data Labels
for bar in count.containers:
    count.bar_label(bar)

plt.tight_layout()
plt.show()
```


    
![png](output_30_0.png)
    


**7. Monthly Order Volumes**


```python
query = """SELECT MONTH(order_purchase_timestamp) as Monthly,
COUNT(order_id) as Order_Count
FROM orders
GROUP BY Monthly
ORDER BY Monthly ASC;"""


cur.execute(query)

data = cur.fetchall()
Monthly_vol= pd.DataFrame(data, columns = ["Month", "Order_Count"])


# Visualize 
plt.figure(figsize = (14,6))
plt.style.use('bmh')

month_names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
Monthly_vol['Month_name'] = Monthly_vol['Month'].apply(lambda x : month_names[x-1])

# Seaborn Line plot
sns.lineplot(data = Monthly_vol, x = "Month_name", y = "Order_Count" , 
             marker = 'o', mfc = 'coral', 
             mec = 'k', ms = 8, 
             linewidth = 2, color = 'dodgerblue')


plt.title("Monthly Order Volume", fontweight='bold', fontsize=15)
plt.xlabel("Month", fontweight='bold', fontsize=11)
plt.ylabel("Order Count", fontweight='bold', fontsize=11)

plt.tight_layout()
plt.show()
```


    
![png](output_32_0.png)
    


# Intermediate Queries

**1. Calculate the number of orders per month in 2018.**


```python
query = """SELECT monthname(order_purchase_timestamp) as Month, count(order_id) as Order_count FROM orders
WHERE year(order_purchase_timestamp) = 2018
GROUP BY  Month
"""

cur.execute(query)

data = cur.fetchall()
orders_2018 = pd.DataFrame(data, columns =["Months", "Order_Count"])

plt.figure(figsize = (10,6))
orders = ['January','February','March','April','May','June','July','August','September','October']

count = sns.barplot(x = orders_2018['Months'],y = orders_2018['Order_Count'], data = orders_2018, order = orders, edgecolor = 'black', palette = 'spring', linewidth = 2)
 
plt.title("Orders per month in 2018." ,  fontweight = 'bold' , fontsize = 14)
plt.xlabel("Months", fontweight = 'bold' , fontsize = 10)
plt.ylabel('Order Count', fontweight = 'bold' , fontsize = 10)
           
plt.xticks(rotation = 25)


for bar in count.containers:
    count.bar_label(bar)

plt.tight_layout()
plt.show()
```


    
![png](output_35_0.png)
    



```python
orders_2018
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Months</th>
      <th>Order_Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>July</td>
      <td>12584</td>
    </tr>
    <tr>
      <th>1</th>
      <td>August</td>
      <td>13024</td>
    </tr>
    <tr>
      <th>2</th>
      <td>February</td>
      <td>13456</td>
    </tr>
    <tr>
      <th>3</th>
      <td>June</td>
      <td>12334</td>
    </tr>
    <tr>
      <th>4</th>
      <td>March</td>
      <td>14422</td>
    </tr>
    <tr>
      <th>5</th>
      <td>January</td>
      <td>14538</td>
    </tr>
    <tr>
      <th>6</th>
      <td>May</td>
      <td>13746</td>
    </tr>
    <tr>
      <th>7</th>
      <td>April</td>
      <td>13878</td>
    </tr>
    <tr>
      <th>8</th>
      <td>September</td>
      <td>32</td>
    </tr>
    <tr>
      <th>9</th>
      <td>October</td>
      <td>8</td>
    </tr>
  </tbody>
</table>
</div>



**2. Find the average number of products per order, grouped by customer city.**


```python
query = """with count_per_order as
(SELECT orders.order_id, orders.customer_id, count(orders_items.order_id) as oc
FROM orders JOIN orders_items
ON orders.order_id = orders_items.order_id
GROUP BY  orders.order_id, orders.customer_id)

SELECT customers.customer_city, round(avg(count_per_order.oc), 2) as Avg_orders
FROM customers JOIN count_per_order
ON customers.customer_id = count_per_order.customer_id
GROUP BY customers.customer_city
ORDER BY Avg_orders Desc
"""
 
cur.execute(query)

data = cur.fetchall()

avg_order = pd.DataFrame(data, columns = ["City", "Avg_orders"])

# only top 10
avg_order = avg_order.head(10)
```


```python
colors = ['#bc0c1c'] + ['steelblue'] * 9

plt.figure(figsize = (13,8))


plt.barh(y = avg_order['City'], width = avg_order['Avg_orders'],color = colors, edgecolor = 'k', linewidth = 2 )

plt.gca().invert_yaxis()

plt.title("The average number of products per order, grouped by customer city." ,  fontweight = 'bold' , fontsize = 16)
plt.xlabel('Average Number of Products per Order', fontweight = 'bold' , fontsize = 11)
plt.ylabel('City', fontweight = 'bold' , fontsize = 11)


plt.tight_layout()
plt.show()
```


    
![png](output_39_0.png)
    



```python
avg_order.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Avg_orders</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>padre carvalho</td>
      <td>28.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>celso ramos</td>
      <td>26.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>datas</td>
      <td>24.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>candido godoi</td>
      <td>24.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>matias olimpio</td>
      <td>20.00</td>
    </tr>
    <tr>
      <th>5</th>
      <td>cidelandia</td>
      <td>16.00</td>
    </tr>
    <tr>
      <th>6</th>
      <td>curralinho</td>
      <td>16.00</td>
    </tr>
    <tr>
      <th>7</th>
      <td>picarra</td>
      <td>16.00</td>
    </tr>
    <tr>
      <th>8</th>
      <td>morro de sao paulo</td>
      <td>16.00</td>
    </tr>
    <tr>
      <th>9</th>
      <td>teixeira soares</td>
      <td>16.00</td>
    </tr>
  </tbody>
</table>
</div>



**3. Calculate the percentage of total revenue contributed by each product category.**


```python
query = """SELECT CONCAT(UPPER(LEFT(products.product_category,1)), LOWER(SUBSTRING(products.product_category, 2))),
round(sum((payments.payment_value)/(SELECT sum(payment_value) FROM payments))* 100,2) as Percentage
FROM products JOIN orders_items
ON products.product_id = orders_items.product_id
JOIN payments
ON payments.order_id = orders_items.order_id
GROUP BY products.product_category
ORDER BY Percentage DESC
"""

cur.execute(query)

data = cur.fetchall()

revenue_pct = pd.DataFrame(data, columns = ["Product_category","Percentage"])
revenue_pct ['Percentage'] = revenue_pct ['Percentage'].astype(str) + ' %'

```


```python
revenue_pct .head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product_category</th>
      <th>Percentage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bed table bath</td>
      <td>42.79 %</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Health beauty</td>
      <td>41.41 %</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Computer accessories</td>
      <td>39.61 %</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Furniture decoration</td>
      <td>35.73 %</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Watches present</td>
      <td>35.71 %</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Sport leisure</td>
      <td>34.78 %</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Housewares</td>
      <td>27.35 %</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Automotive</td>
      <td>21.3 %</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Garden tools</td>
      <td>20.95 %</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Cool stuff</td>
      <td>19.48 %</td>
    </tr>
  </tbody>
</table>
</div>



**4. Identify the correlation between product price and the number of times a product has been purchased.**


```python
query = """SELECT products.product_category AS Category,
count(orders_items.price) AS Count,
round(AVG(orders_items.price),2) AS Average_price
FROM products JOIN orders_items
ON products.product_id = orders_items.product_id
GROUP BY Category
ORDER BY Average_price DESC;
"""

cur.execute(query)

data = cur.fetchall()
corr_prd_price = pd.DataFrame(data, columns = ["Product_category","Count", "Average_price"])

#To find out Correlation
corr = corr_prd_price.corr(numeric_only = True)
```


```python
corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Count</th>
      <th>Average_price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Count</th>
      <td>1.000000</td>
      <td>-0.106315</td>
    </tr>
    <tr>
      <th>Average_price</th>
      <td>-0.106315</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
corr_prd_price.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product_category</th>
      <th>Count</th>
      <th>Average_price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>PCs</td>
      <td>812</td>
      <td>1098.34</td>
    </tr>
    <tr>
      <th>1</th>
      <td>HOUSE PASTALS OVEN AND CAFE</td>
      <td>304</td>
      <td>624.29</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ELECTRICES 2</td>
      <td>952</td>
      <td>476.12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Agro Industria e Comercio</td>
      <td>848</td>
      <td>342.12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>musical instruments</td>
      <td>2720</td>
      <td>281.62</td>
    </tr>
    <tr>
      <th>5</th>
      <td>electrostile</td>
      <td>2716</td>
      <td>280.78</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Kitchen portable and food coach</td>
      <td>60</td>
      <td>264.57</td>
    </tr>
    <tr>
      <th>7</th>
      <td>fixed telephony</td>
      <td>1056</td>
      <td>225.69</td>
    </tr>
    <tr>
      <th>8</th>
      <td>CONSTRUCTION SECURITY TOOLS</td>
      <td>776</td>
      <td>208.99</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Watches present</td>
      <td>23964</td>
      <td>201.14</td>
    </tr>
  </tbody>
</table>
</div>



 **5. Calculate the total revenue generated by each seller, and rank them by revenue.**


```python
# Using Window function.
query = """SELECT *, dense_rank() over(ORDER BY Revenue DESC) as rank_seller FROM
(SELECT DISTINCT orders_items.seller_id, 
round(sum(payments.payment_value),2) Revenue
FROM orders_items JOIN payments
ON payments.order_id = orders_items.order_id
GROUP BY orders_items.seller_id) as Seller_group
LIMIT 10
"""

cur.execute(query)

data = cur.fetchall()

seller_rank = pd.DataFrame(data, columns = ["Seller_id","Revenue", "Rank"])

# BAR Ploting
plt.figure(figsize = (9,5))
sns.barplot(data = seller_rank, x = seller_rank['Seller_id'], y = seller_rank['Revenue'], edgecolor = 'black', linewidth = 2, palette = 'coolwarm')

plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))
plt.title("Total revenue generated by each seller, and rank them by revenue." ,  fontweight = 'bold' , fontsize = 14)
plt.xlabel("Seller", fontweight = 'bold')
plt.ylabel("Revenue", fontweight = 'bold')
plt.xticks(rotation = 90)


plt.show()

print(f'Seller Id :- {seller_rank['Seller_id'][0]} is in the First Rank for generating the maximum revenue ')
```


    
![png](output_49_0.png)
    


    Seller Id :- 7c67e1448b00f6e969d365cea6b010ab is in the First Rank for generating the maximum revenue 
    


```python
seller_rank
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Seller_id</th>
      <th>Revenue</th>
      <th>Rank</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7c67e1448b00f6e969d365cea6b010ab</td>
      <td>2028667.63</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1025f0e2d44d7041d6cf58b6550e0bfa</td>
      <td>1232888.16</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4a3ca9315b744ce9f8e9374361493884</td>
      <td>1204981.08</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1f50f920176fa81dab994f9023523100</td>
      <td>1161013.68</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>53243585a1d6dc2643021fd1853d8905</td>
      <td>1139612.32</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>da8622b14eb17ae2831f4ac5b9dab84a</td>
      <td>1088877.28</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>4869f7a5dfa277a7dca6462dcf3b52b2</td>
      <td>1056664.48</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>955fee9216a65b617aa5c0531780ce60</td>
      <td>945289.20</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>fa1c13f2614d7b5c4749cbc52fecda94</td>
      <td>826052.92</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>7e93a43ef30c4f03f38b393420bc753a</td>
      <td>740536.84</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
</div>



# Advanced Queries.

**1. Calculate the moving average of order values for each customer over their order history.**


```python
query = """SELECT customer_id, order_purchase_timestamp, payment,
AVG(payment) OVER (Partition By customer_id ORDER BY order_purchase_timestamp
ROWS BETWEEN 2 Preceding AND current row) as Moving_avg
FROM
(SELECT orders.customer_id, payments.payment_value as payment, orders.order_purchase_timestamp
FROM orders JOIN payments 
ON payments.order_id = orders.order_id) as order_pay 
"""

cur.execute(query)

data = cur.fetchall()
moving_avg = pd.DataFrame(data, columns = ["Customer ID", "Order purchase timestamp" ,"Price" ,"Moving Average"])

print("The moving average of order values for each customer over their order history.\n")
moving_avg
```

    The moving average of order values for each customer over their order history.
    
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Order purchase timestamp</th>
      <th>Price</th>
      <th>Moving Average</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>00012a2ce6f8dcda20d059ce98491703</td>
      <td>2017-11-14 16:08:26</td>
      <td>114.74</td>
      <td>114.739998</td>
    </tr>
    <tr>
      <th>1</th>
      <td>00012a2ce6f8dcda20d059ce98491703</td>
      <td>2017-11-14 16:08:26</td>
      <td>114.74</td>
      <td>114.739998</td>
    </tr>
    <tr>
      <th>2</th>
      <td>00012a2ce6f8dcda20d059ce98491703</td>
      <td>2017-11-14 16:08:26</td>
      <td>114.74</td>
      <td>114.739998</td>
    </tr>
    <tr>
      <th>3</th>
      <td>00012a2ce6f8dcda20d059ce98491703</td>
      <td>2017-11-14 16:08:26</td>
      <td>114.74</td>
      <td>114.739998</td>
    </tr>
    <tr>
      <th>4</th>
      <td>000161a058600d5901f007fab4c27140</td>
      <td>2017-07-16 09:40:32</td>
      <td>67.41</td>
      <td>67.410004</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>415539</th>
      <td>ffffa3172527f765de70084a7e53aae8</td>
      <td>2017-09-02 11:53:32</td>
      <td>45.50</td>
      <td>45.500000</td>
    </tr>
    <tr>
      <th>415540</th>
      <td>ffffe8b65bbe3087b653a978c870db99</td>
      <td>2017-09-29 14:07:03</td>
      <td>18.37</td>
      <td>18.370001</td>
    </tr>
    <tr>
      <th>415541</th>
      <td>ffffe8b65bbe3087b653a978c870db99</td>
      <td>2017-09-29 14:07:03</td>
      <td>18.37</td>
      <td>18.370001</td>
    </tr>
    <tr>
      <th>415542</th>
      <td>ffffe8b65bbe3087b653a978c870db99</td>
      <td>2017-09-29 14:07:03</td>
      <td>18.37</td>
      <td>18.370001</td>
    </tr>
    <tr>
      <th>415543</th>
      <td>ffffe8b65bbe3087b653a978c870db99</td>
      <td>2017-09-29 14:07:03</td>
      <td>18.37</td>
      <td>18.370001</td>
    </tr>
  </tbody>
</table>
<p>415544 rows × 4 columns</p>
</div>



**2. Calculate the cumulative sales per month for each year.**


```python
query = """SELECT years, months, payment , sum(payment)
over (ORDER BY years, months) cumulative_sales
FROM 
(SELECT month(orders.order_purchase_timestamp) as months , year(orders.order_purchase_timestamp) as years,
round(sum(payments.payment_value),2) as payment
FROM orders JOIN payments
ON orders.order_id = payments.payment_value
GROUP BY months, years
ORDER BY months, years) as order_pay; 
"""

cur.execute(query)

data = cur.fetchall()
df = pd.DataFrame(data, columns = ["Years", "Months" ,"Price", "SUM Payments"])
df

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Years</th>
      <th>Months</th>
      <th>Price</th>
      <th>SUM Payments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2016</td>
      <td>9</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2016</td>
      <td>10</td>
      <td>360072.0</td>
      <td>360072.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016</td>
      <td>12</td>
      <td>0.0</td>
      <td>360072.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017</td>
      <td>1</td>
      <td>607128.0</td>
      <td>967200.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2017</td>
      <td>2</td>
      <td>1416372.0</td>
      <td>2383572.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2017</td>
      <td>3</td>
      <td>2304184.0</td>
      <td>4687756.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2017</td>
      <td>4</td>
      <td>2056356.0</td>
      <td>6744112.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2017</td>
      <td>5</td>
      <td>3180624.0</td>
      <td>9924736.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2017</td>
      <td>6</td>
      <td>2765740.0</td>
      <td>12690476.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2017</td>
      <td>7</td>
      <td>3395988.0</td>
      <td>16086464.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2017</td>
      <td>8</td>
      <td>3760676.0</td>
      <td>19847140.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2017</td>
      <td>9</td>
      <td>3414032.0</td>
      <td>23261172.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2017</td>
      <td>10</td>
      <td>4454360.0</td>
      <td>27715532.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2017</td>
      <td>11</td>
      <td>6511752.0</td>
      <td>34227284.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2017</td>
      <td>12</td>
      <td>4632528.0</td>
      <td>38859812.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2018</td>
      <td>1</td>
      <td>6388072.0</td>
      <td>45247884.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2018</td>
      <td>2</td>
      <td>5529400.0</td>
      <td>50777284.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2018</td>
      <td>3</td>
      <td>6307676.0</td>
      <td>57084960.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2018</td>
      <td>4</td>
      <td>5852476.0</td>
      <td>62937436.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2018</td>
      <td>5</td>
      <td>5818312.0</td>
      <td>68755748.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2018</td>
      <td>6</td>
      <td>5282344.0</td>
      <td>74038092.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2018</td>
      <td>7</td>
      <td>5583160.0</td>
      <td>79621252.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2018</td>
      <td>8</td>
      <td>5250772.0</td>
      <td>84872024.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2018</td>
      <td>9</td>
      <td>2884.0</td>
      <td>84874908.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2018</td>
      <td>10</td>
      <td>80.0</td>
      <td>84874988.0</td>
    </tr>
  </tbody>
</table>
</div>



**3. Calculate the year-over-year growth rate of total sales.**


```python
query = """with a as(SELECT year(orders.order_purchase_timestamp) as years,
round(sum(payments.payment_value),2) as payment
FROM orders JOIN payments
ON orders.order_id = payments.order_id
GROUP BY years
ORDER BY years)


SELECT years, 
round((payment - lag(payment, 1) over(ORDER BY years))/
lag(payment, 1) over(ORDER BY years)) * 100 from a"""




cur.execute(query)

data = cur.fetchall()

yoy = pd.DataFrame(data, columns = ["Years", "YOY Growth"])
yoy

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Years</th>
      <th>YOY Growth</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2016</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2017</td>
      <td>12100.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2018</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>



**4. Identify the top 3 customers who spent the most money in each year.**


```python
query = """SELECT years, customer_id, payment, d_rank
FROM
(SELECT year(orders.order_purchase_timestamp) as years,
orders.customer_id,
sum(payments.payment_value) as payment,
dense_rank() over (partition by year(orders.order_purchase_timestamp) 
ORDER BY sum(payments.payment_value) desc) d_rank
FROM orders JOIN payments
ON payments.order_id = orders.order_id
GROUP BY years,
orders.customer_id) as a
WHERE d_rank <= 3"""


cur.execute(query)

data = cur.fetchall()
top_3 = pd.DataFrame(data, columns = ["Years", "Customer ID", "Payment", "Rank"])
top_3

plt.figure(figsize = (9,5))
sns.barplot(data = top_3, x = 'Customer ID', y = top_3['Payment'],hue = 'Years', edgecolor = 'black', linewidth = 2, palette = 'summer')

plt.title("Top 3 customers who spent the most money in each year." ,  fontweight = 'bold' , fontsize = 14)
plt.xlabel("Customer ID", fontweight = 'bold')
plt.ylabel("Payment", fontweight = 'bold')
plt.xticks(rotation = 90)

plt.show()
```


    
![png](output_59_0.png)
    


# DashBoard


```python

import matplotlib.gridspec as gridspec

fig = plt.figure(figsize=(22, 12))
gs = gridspec.GridSpec(2, 3, width_ratios=[1, 1, 1], height_ratios=[1, 1])
fig.suptitle("Ecommerce Sales Dashboard",color = 'indianred', fontsize=20, fontweight="bold")

fig.patch.set_facecolor('navajowhite')

# 1. Sales by Product Category
ax0 = plt.subplot(gs[0, 0])
plt.barh(y = clean_df["Category"], width = clean_df["Sales"], edgecolor= 'black' , linewidth = 2, color = 'goldenrod' , hatch = '\\')
ax0.set_title('Sales by Product Category', fontsize=14)
ax0.set_xlabel('Sales', color = 'darkblue')
ax0.set_ylabel('Category', color = 'darkblue')
plt.gca().invert_yaxis()

# 2. Top Customers by Revenue
customers = ['aa872','6c120','a690c','62b93','eb526','caa62','35ed6','60987','960bf','40ccb']
ax1 = plt.subplot(gs[0, 1])
sns.barplot(data = cust_reve, x = cust_reve["Customer"], y = cust_reve["Revenue"], edgecolor= 'black' , linewidth = 2, color = 'darkcyan')
ax1.set_title('Top Customers by Revenue', fontsize=14)
ax1.set_xlabel('Customer ID', color = 'darkblue')
ax1.set_ylabel('Revenue', color = 'darkblue')
plt.xticks(rotation = 30,ticks = range(0,10), labels = customers)

# 3. Sales by State
ax2 = plt.subplot(gs[0, 2])
plt.bar(customer_count['State'], customer_count['Count of customers'], edgecolor = 'black', color = colors)
ax2.set_title('Sales by State', fontsize=14)
ax2.set_xlabel('Sales', color = 'darkblue')
ax2.set_ylabel('State', color = 'darkblue')

# 4. Monthly Order Volumes
ax3 = plt.subplot(gs[1, 0:2])
sns.lineplot(data = Monthly_vol, x = "Month_name", y = "Order_Count" , 
             marker = 'o', mfc = 'coral', 
             mec = 'k', ms = 10, 
             linewidth = 2, color = 'dodgerblue' )


ax3.set_title('Monthly Order Volumes', fontsize=14)
ax3.set_xlabel('Month', color = 'darkblue')
ax3.set_ylabel('Order Count', color = 'darkblue')


# 5. Top Sellers by Revenue
ax4 = plt.subplot(gs[1, 2])
sellers = ['Seller 1','Seller 2','Seller 3','Seller 4','Seller 5','Seller 6','Seller 7','Seller 8','Seller 9','Seller 10']

sns.barplot(data = seller_rank, x = 'Seller_id', y = 'Revenue', edgecolor = 'black', linewidth = 2, palette = 'coolwarm')
ax4.set_title('Top Sellers by Revenue', color = 'k', fontsize=14)
ax4.set_xlabel('Seller ID', color = 'darkblue')
ax4.set_ylabel('Revenue', color = 'darkblue')
plt.xticks(rotation = 40, ticks = range(0,10), labels = sellers)

plt.tight_layout(rect=[0, 0.03, 0.1, 0.93])
plt.show()

# plt.savefig("Ecommerce Sales Dashboard.png", dpi = 300, bbox_inches = 'tight')
```


    
![png](output_61_0.png)
    

